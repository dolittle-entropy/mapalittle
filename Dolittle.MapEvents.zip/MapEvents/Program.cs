﻿using MapEvents.CommandLine;
using McMaster.Extensions.CommandLineUtils;

using System;

namespace MapEvents
{
    [Command(Name = "MapEvents", Description ="Utility for detecting unwanted errors and producing Graph/Edge data")]
    [VersionOption("MapEvents v1.0.0 - Copyright 2020 Dolittle AS")]
    [Subcommand(
        typeof(Events)
        )]
    public class Program : CommandBase
    {
        public static int Main(string[] args) 
            => CommandLineApplication.Execute<Program>(args);

        private void OnExecute(CommandLineApplication app)
        {
            app.ShowHelp();
            Console.WriteLine("Gotta choose a command!");
        }
    }
}
