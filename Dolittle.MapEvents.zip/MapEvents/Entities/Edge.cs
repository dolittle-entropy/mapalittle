﻿namespace MapEvents.Entities
{
    public class Edge
    {
        public int From { get; set; }

        public int To { get; set; }
    }
}
