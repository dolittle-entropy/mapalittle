﻿using MapEvents.Processors;
using McMaster.Extensions.CommandLineUtils;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;

namespace MapEvents.CommandLine
{
    [Command("events", Description ="Map all events to their EventHandlers into the selected output format")]
    [VersionOption("MapEvents.Events v1.0.1")]
    public class Events : CommandBase
    {
        [Option(Description = "Set this flag to ignore issues found")]
        public bool IgnoreEvents { get; set; }

        public async void OnExecute(CommandLineApplication app)
        {
            app.ShowVersion();
            Out.Dump($"Discovering DLLs...");
            DllDiscovery.LoadDllFiles(InputFolder);

            var eventType = DllDiscovery.FindEventTypeInDlls();
            if(!eventType.Found)
            {
                Out.Fail("No event types found. Is this a Dolittle project output folder?");
                return;
            }

            DllDiscovery.FindAllEvents();
            DllDiscovery.MapEventsToEventHandlers();

            
            
            if(!IgnoreEvents)
            {
                DllDiscovery.ReportIssues();
            }

            Out.Dump("Writing files");
            DllDiscovery.WriteOutputFiles(OutputFolder, PreferJson);

            Out.Dump("All done", overline: true);

            await Task.CompletedTask;
        }
    }
}
